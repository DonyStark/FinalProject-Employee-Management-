GROUP 2
GROUP MEMBERS – DONNIYOR, BARK, FORTUNE, AZIM
FINAL PROJECT
EMPLOYEE MANAGEMENT SYSTEM (CLASS DIAGRAM SCRIPT)
This class diagram represents an employee management system. It includes various classes and
their associated attributes and methods.
The central class is the Employee class, which contains attributes such as employeeID,
firstName, lastName, email, phoneNumber, birthDate, hireDate, position, department, and
payroll. This class serves as a blueprint for creating employee objects with their unique
characteristics.
The EmployeeManager class manages a list of employees and provides methods for adding,
removing, and retrieving employees. It has a single attribute employee that holds a list of
Employee objects. This class is responsible for managing employee data and performing basic
operations such as adding or removing employees.
The EmployeeDatabase class uses a DataTable to store employee data. The employeeTable
attribute holds the data of all the employees in the system in a table format. This class serves as
a database for employee data and provides methods for querying and updating the employee
table.
The EmployeeSearchManager class is responsible for searching employees based on different
criteria such as first name, last name, email, department, position, and salary range. It has
various search methods such as searchByFirstName(), searchByLastName(), searchByEmail(),
searchByDepartment(), searchByPosition(), and searchBySalaryRange(). These methods return a
list of Employee objects that match the search criteria. The class also has a method to mark
employee attendance called markAttendance().
The EmployeeReportManager generates reports based on employee data and stores them in
the employeesReport attribute. This class has a single attribute employeesReport, which holds
a report object. The generateReport() method creates a report based on employee data, which
can be used for various purposes such as performance analysis, payroll calculation, or employee
review.
The Notification class stores information about notifications sent to employees, including the
employee, message, and time. It has three attributes: employee, message, and time. This class
serves as a notification system for employees, which can be used to send messages to
employees or remind them of upcoming events.
The Task class represents tasks assigned to employees and has attributes such as taskID, title,
description, dueDate, and isCompleted. This class is responsible for managing employee tasks
and tracking their progress. The isCompleted attribute indicates whether the task has been
completed or not.
The Payroll class tracks employee clock-in and clock-out times and calculates their payroll. It has
three attributes: employee, clockInTime, and clockOutTime. This class serves as a payroll
system for employees, which can be used to calculate their salary based on their working hours.
The TaskAssigner class is responsible for assigning tasks to employees from a list of employees.
It has two attributes: employee and employeeList. The assignTask() method assigns a task to an
employee from the employeeList.
Finally, the EmailSender class sends emails to employees with the provided email address,
subject, and body. This class serves as an email system for employees, which can be used to
send emails to employees for various purposes such as task reminders, notifications, or
performance feedback.
Overall, this class diagram represents a comprehensive employee management system with
features such as employee data management, search functionality, task assignment,
notification, and payroll calculation. It provides a robust framework for managing employee
data and optimizing employee performance.

Project Presentation 
1. Introduction:
    ◦ The Employee Management System project aims to simplify the process of managing employee information and calculating their total wages. Its purpose is to provide an easy-to-use and efficient tool for managing employee data.
    ◦ The project uses various programming concepts such as classes, interfaces, abstract classes, MAUI GUI for the user interface, and exception handling.
    ◦ The project's primary goals are to allow users to manage employee data efficiently and perform essential calculations, such as total wages.

2. Functionality:
    ◦ The core functionality of the project includes managing employee data, calculating total wages, and providing an intuitive user interface.
    ◦ Classes, interfaces, and abstract classes are used to create a modular and extensible structure, allowing different components to interact seamlessly.
    ◦ Exception handling is used throughout the project to ensure proper error handling and maintain application stability.



3. Classes and Inheritance:
    ◦ The project includes classes such as `CalculateTotalWage`, `Employees`, and `IdentityEventArgs`, each serving a specific purpose in the system.
    ◦ Inheritance is utilized to create a hierarchy of classes, enabling code reuse and extensibility. For example, `IdentityEventArgs` inherits from the `EventArgs` class.
    ◦ Interfaces and abstract classes are implemented to provide a contract for the classes, ensuring consistent behavior across different components.

4. MAUI GUI:
    ◦ The MAUI (Multi-platform App UI) GUI framework is used to create a user-friendly and responsive interface for the Employee Management System. This allows users to interact with the application effectively across various platforms, such as Windows, macOS, iOS, and Android.


5. Exceptions:
    ◦ Exception handling is employed throughout the project to catch errors and prevent the application from crashing. This ensures a smooth user experience.
    ◦ Examples of exceptions in the project could include handling invalid input, file I/O errors, or other runtime issues that might arise.

6. Conclusion:
    ◦ In summary, the Employee Management System is a well-designed application that utilizes various programming concepts, such as classes, inheritance, interfaces, abstract classes, MAUI GUI, and exception handling.
    ◦ The project's primary goals are to provide an efficient and user-friendly tool for managing employee data and calculating total wages.
    ◦ With proper implementation and attention to detail, the Employee Management System serves as a valuable asset for any organization looking to streamline their employee management processes.

